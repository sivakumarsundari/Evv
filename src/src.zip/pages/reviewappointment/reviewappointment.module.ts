import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ReviewappointmentPage } from './reviewappointment';

@NgModule({
  declarations: [
    ReviewappointmentPage,
  ],
  imports: [
    IonicPageModule.forChild(ReviewappointmentPage),
  ],
})
export class ReviewappointmentPageModule {}
