import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { CgsignatureverificationPage } from '../cgsignatureverification/cgsignatureverification';

/**
 * Generated class for the Cgreview1Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-cgreview1',
  templateUrl: 'cgreview1.html',
})
export class Cgreview1Page {
  records:record[];
  mark:cmark[];
  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.records=[
      {
         timeIn:"11.00 am",
         timeOut:"2.00 am",
    }
  ];
  this.mark=[{
    type:"Bathing",
  },
  {
    type:"Grooming",
  },
  {
    type:"Eating",
  },];
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Cgreview1Page');
  }
  submit(){
    this.navCtrl.push(CgsignatureverificationPage);
  }
}
export class record{
  timeIn:String;
  timeOut:String;
}
export class cmark{
  type:string;
}
