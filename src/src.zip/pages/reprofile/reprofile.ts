import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { HttpClient } from '@angular/common/http';
import { GlobalPage } from '../global/global';

/**
 * Generated class for the ReprofilePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-reprofile',
  templateUrl: 'reprofile.html',
})
export class ReprofilePage {
 proinfo:pro[];
 cliprodet:any = [];
  constructor(public navCtrl: NavController, public navParams: NavParams,
    public loadingCtrl: LoadingController,public http: HttpClient,
  public global:GlobalPage) {
    this.proinfo=[{
      img:"assets/imgs/profile5.jpg",
      name:"Tom Moscow",
      care:"Bathing,Grooming,Eating",
    }];
  }

  ionViewDidLoad() {

    console.log('ionViewDidLoad ReprofilePage');

    let loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    loading.present();  
    let url = "api/Profilesetup/clieprofile?";
    let myParams = new URLSearchParams();
    myParams.append("clientNumber", this.global.clientId.toString());
    this.http.get(url + myParams).subscribe(
      (data: any) => {
        console.log(data);
        this.cliprodet = data;
       
        loading.dismiss();
      },
      err => {
        console.log(err);
       loading.dismiss();
      });
  }
  back(){
    this.navCtrl.pop();
  }
}
export class pro{
  img:any;
  name:String;
  care:String;

}
