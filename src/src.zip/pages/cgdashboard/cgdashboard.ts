
import { Component, Pipe, PipeTransform } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
import { CgviewappointmentPage } from '../cgviewappointment/cgviewappointment';
import { CgcompletetimesheetPage } from '../cgcompletetimesheet/cgcompletetimesheet';
import { HttpClient } from '@angular/common/http';
import { Storage } from '@ionic/storage';
import { GlobalPage } from '../global/global';
import { Observable } from "rxjs";
import "rxjs/add/operator/map";
import "rxjs/add/operator/catch";
import "rxjs/add/operator/toPromise";
import { Time } from '@angular/common';
import { Geolocation } from '@ionic-native/geolocation';
// import { MinuteSecondsPipe } from '../../pipes/minute-seconds/minute-seconds';



@IonicPage()
@Component({
  selector: 'page-cgdashboard',
  templateUrl: 'cgdashboard.html',
})
export class CgdashboardPage {
  // records: record[];
  public show: boolean = true;
  someCondition: boolean;
  latitude: number;
  longitude: number;
  schedulelist: any = [];
  currentdateTime$: Observable<any>;
  constructor(public navCtrl: NavController, public navParams: NavParams, public global: GlobalPage,
    private alertCtrl: AlertController, public http: HttpClient, public storage: Storage,
    public loadingCtrl: LoadingController, private geolocation: Geolocation) {

    this.currentdateTime$ = Observable.interval(1000).map(x => new Date());
    // this.records = [
    //   {

    //     Apnttime: "9:00 AM",
    //     cgname: "Mike Jones",
    //     duration: "2 hours",
    //     isstarted: false,
    //     image: "assets/imgs/profile.jpg"
    //   }
    // ];
  }
  currentdate: Date = new Date();

  current: Time;
  differentmin(startDt) {
    console.log(startDt);

    var diff = (new Date(startDt).getTime() - new Date().getTime()) / 1000;
    diff /= 60;

    var hour = Math.floor(diff / 60)
    var min = diff % 60;

    return hour + " hrs" + min + " min";
    // this.current=time;
    // var t= this.currentdate.(time);
    // console.log(t);
    // return t;

  }

  ConvertHM(min) {
    console.log(min);

    return Math.floor(min / 60) + " hrs " + min % 60 + " min";
  }
  // ionViewDidLoad() {
  //   console.log('ionViewDidLoad CgdashboardPage');
  // }
  ionViewWillEnter() {
    console.log('ionViewwill entre CgdashboardPage');
    console.log(this.global.iscgdashreload);
    if (this.global.iscgdashreload) {
      this.ionViewDidLoad();
      console.log("trur");

    }

  }
  ionViewDidLoad() {
    this.show = true;
    let agencyId: any = 1;
    let employeeId: any = 5;
    let loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    console.log(this.global);

    loading.present();
    let url = "api/Cgtimesheets/getcglist?";
    let myParams = new URLSearchParams();
    myParams.append("agencyid", this.global.agencyId.toString());
    myParams.append("employeeId", this.global.employeeId.toString());
    this.http.get(url + myParams).subscribe(
      (data: any) => {
        console.log(data);
        this.schedulelist = data;
        this.global.iscgdashreload = false;
        loading.dismiss();
      },
      err => {
        console.log(err);
        loading.dismiss();
      });
  }
  getlocation() {
   return this.geolocation.getCurrentPosition().then((resp) => {
      console.log("latitude and longitude");

      console.log(resp.coords.latitude);
      console.log(resp.coords.longitude);
      this.latitude = resp.coords.latitude;
      this.longitude = resp.coords.longitude;


    }).catch((error) => {
      this.latitude = 0;
      this.longitude = 0;
      console.log('Error getting location', error);
    });
  }
  presentAlert(item) {
    console.log(item);
    this.getlocation();
    let alert = this.alertCtrl.create({
      title: 'Activities to Complete',
      subTitle: 'Mike need help bathing,grooming and eating.',
      buttons: [{
        text: 'Got it,thanks!', handler: () => {
          // item.start= true;

          console.log("Start button");
          this.starrttimecard(item);

        }
      }]
    });
    alert.present();
  }
  starrttimecard(clientdata) {

    console.log(clientdata);
    let loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    loading.present();
    let url = "api/Cgtimesheets/startTC?";
    let myParams = new URLSearchParams();
    myParams.append("scheduleId", clientdata.scheduleId);
    myParams.append("agencyId", clientdata.agencyId);
    myParams.append("latitude", this.latitude.toString());
    myParams.append("longitude", this.longitude.toString());
    this.http.get(url + myParams).subscribe(
      (data: any) => {
        console.log(data);

        if (data) {
          clientdata.isStarted = true;
          clientdata.timeCardId = data;
        }
        //  this.schedulelist = data;
        loading.dismiss();

      },
      err => {
        console.log(err);
        loading.dismiss();
      });

  }

  viewclientdetails(clientdetails) {
    console.log(clientdetails);
    this.navCtrl.push(CgviewappointmentPage, {
      "ScheduleId": clientdetails.scheduleId, "agencyId": clientdetails.agencyId,
      "isCompleted": clientdetails.isCompleted, "isCancelled": clientdetails.isCancelled, "isStarted": clientdetails.isStarted
    });
    err => {
      console.log(err);
    }
  }
  completetimesheetpagelat(ctsplat) {
    let loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    loading.present();
    this.geolocation.getCurrentPosition().then((resp) => {
      console.log("latitude and longitude stop");

      console.log(resp.coords.latitude);
      console.log(resp.coords.longitude);
      this.latitude = resp.coords.latitude;
      this.longitude = resp.coords.longitude;
      loading.dismiss();
      this.completetimesheetpage(ctsplat)

    }).catch((error) => {
      this.latitude = 0;
      this.longitude = 0;
      console.log('Error getting location', error);
      loading.dismiss();
      this.completetimesheetpage(ctsplat)
    });

  }

  completetimesheetpage(ctsp) {
    let loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    loading.present();

    this.getlocation().then((data)=>{
      console.log(ctsp);

      let url = "api/Cgtimesheets/endTC?";
      let myParams = new URLSearchParams();
      myParams.append("timecardId", ctsp.timeCardId);
      myParams.append("agencyId", ctsp.agencyId);
      myParams.append("latitude", this.latitude.toString());
      myParams.append("longitude", this.longitude.toString());
      this.http.get(url + myParams).subscribe(
        (data: any) => {
          console.log(data);
          ctsp.isCompleted = true;
          this.wantedStart();
          loading.dismiss();
        },
        err => {
          console.log(err);
          loading.dismiss();
        });
    });
    // loading.present();
   

  }


  wantedStart() {
    let isfetch = false;
    this.schedulelist.some(element => {
      if (!element.isStarted && !element.isWantStarted && !isfetch && !element.isCancelled) {
        element.isWantStarted = true;
        isfetch = true;
        return !element.isStarted && !element.isWantStarted;
      }
    });
  }

  SubmitTimesheet(tcvalue) {
    console.log(tcvalue);
    this.navCtrl.push(CgcompletetimesheetPage, { "scheduleId": tcvalue.scheduleId, "timecardId": tcvalue.timeCardId });
    err => {
      console.log(err);
    }
  }
  logout() {
    let loading = this.loadingCtrl.create({
      content: 'Logging out...'
    });
    console.log();
    this.storage.remove("loginAuth");
    let alert = this.alertCtrl.create({
      title: 'Confirm!',
      message: 'Do you want to Logout the session?',
      cssClass: "buttonCssa",
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Yes',
          handler: () => {
            loading.present();
            window.location.reload();

            console.log('Logout');
          }
        }
      ]
    });
    loading.dismiss();
    err => {
      console.log(err);
      loading.dismiss();
    }
    alert.present();
  }



  // toggle() {
  //   this.show = !this.show;
  // }

}
export class record {
  Apnttime: string;
  cgname: string;
  duration: string;
  isstarted: boolean;
  image: any;
}
// @Pipe({
//   name: 'minuteSeconds'
// })
// export class MinuteSecondsPipe implements PipeTransform {

//   transform(value: number): string {
//     let  temp = value * 60;
//     const hours = Math.floor((temp/3600));
//     const minutes: number = Math.floor((temp/ 60)/60);
//     const seconds=Math.floor(temp % 3600 % 60);
//     return hours + ':' + minutes + ':' + seconds;
//   }
// }

