import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { CgreviewPage } from '../cgreview/cgreview';
import { CgmissingtimesheetmonthPage } from '../cgmissingtimesheetmonth/cgmissingtimesheetmonth';
import { HttpClient } from '@angular/common/http';
import {CgcompletetimesheetPage} from '../cgcompletetimesheet/cgcompletetimesheet';
/**
 * Generated class for the CgmissingtimesheetPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-cgmissingtimesheet',
  templateUrl: 'cgmissingtimesheet.html',
})
export class CgmissingtimesheetPage {

  constructor(public navCtrl: NavController, public navParams: NavParams, public http: HttpClient,
    public loadingCtrl: LoadingController,) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CgmissingtimesheetPage');
  }
  clientData: any;
  clientName: string;
  monthlist: any = [];
  missingTimeSheet: any =[];
  ionViewWillEnter() {
    let loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    loading.present();
    let client = this.navParams.get("clientData");
    this.clientName = client.clientName;
    let employeeId: any = 5;
    console.log(this.clientName);
    
    let url = "api/CgCareRecipientsLst/RecipientCareHistoryList?";
    let myParams = new URLSearchParams();
    myParams.append("EmployeeId", employeeId);
    myParams.append("clientId", client.clientId);

    this.http.get(url + myParams).subscribe(
      (data: any) => {
        console.log(data);

        this.clientData = data;
        if (data != null) {
          this.clientName = data.clientName;
          this.monthlist = data.monthlist;
          this.missingTimeSheet=data.missingTimeSheet;
        }
        loading.dismiss();
      },
      err => {
        console.log(err);
        loading.dismiss();
      });
  }

  complete(miss) {
    console.log(miss);
 //   alert(miss);
  this.navCtrl.push(CgcompletetimesheetPage,{"scheduleId":miss.scheduleid,"timecardId":miss.timecardId}); 
   // this.navCtrl.push(Cgreview1Page);
  }

  error(clientData) {
    
     this.navCtrl.push(CgmissingtimesheetmonthPage,{"clientData":clientData});
     }
    }

