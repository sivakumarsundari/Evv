import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import {CgprofilepagePage} from '../cgprofilepage/cgprofilepage';
import { HttpClient } from '@angular/common/http';
/**
 * Generated class for the CgtimesheetcarerecipientsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-cgtimesheetcarerecipients',
  templateUrl: 'cgtimesheetcarerecipients.html',
})
export class CgtimesheetcarerecipientsPage {

  records: record[];
  displaydata:any=[];
  constructor(public navCtrl: NavController, public navParams: NavParams,public http: HttpClient,
    public loadingCtrl: LoadingController,) {
    // this.records = [
    //   {
    //     rname: "Beckett Thompson",
    //     day:"Next Appointment Today",       
    //     time: "4:30 PM",
    //     image:"assets/imgs/profile2.jpg"      
    //   },
    //   {
    //     rname: "Hannah Ewing",
    //     day:"Next Appointment 04/15/18",       
    //     time: "4:30 PM",
    //     image:"assets/imgs/profile4.jpg"       
    //   },
    //   {
    //     rname: "Jake Smith",
    //     day:"Next Appointment Today",       
    //     time: "4:30 PM",
    //     image:"assets/imgs/profile1.jpg"     
    //   },
    //   {
    //     rname: "Mike Jones",
    //     day:"Next Appointment Today",       
    //     time: "9:00 AM",
    //     image:"assets/imgs/profile.jpg"       
    //   },
    //   {
    //     rname: "Sally Hanson",
    //     day:"Next Appointment Today",       
    //     time: "12:00 PM",
    //     image:"assets/imgs/profile3.jpg"       
    //   },
     
    // ];
  }

  ionViewWillEnter() {
    
    let agencyId:any = 1;
    let employeeId:any = 5;
    let loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    loading.present();
    let url = "api/CgCareRecipientsLst/RecipientList?";
    let myParams = new URLSearchParams();

    myParams.append("employeeId", employeeId);
    this.http.get(url + myParams).subscribe(
      (data: any) => {
        console.log(data);
       
        this.displaydata=data.careRecipientList;
        loading.dismiss();
      },
    err => {
      console.log(err);
      loading.dismiss();
    });
  }



  ionViewDidLoad() {
    console.log('ionViewDidLoad CgtimesheetcarerecipientsPage');
  }

  viewapp(client){
   
    this.navCtrl.push(CgprofilepagePage,{"clientData":client});
    
  }
}
export class record {
  day: string;
  rname: string;
  time: string;
  image:any;
}
