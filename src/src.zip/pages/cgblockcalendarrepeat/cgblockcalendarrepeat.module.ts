import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgblockcalendarrepeatPage } from './cgblockcalendarrepeat';

@NgModule({
  declarations: [
    CgblockcalendarrepeatPage,
  ],
  imports: [
    IonicPageModule.forChild(CgblockcalendarrepeatPage),
  ],
})
export class CgblockcalendarrepeatPageModule {}
