import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RecarehistoryPage } from './recarehistory';

@NgModule({
  declarations: [
    RecarehistoryPage,
  ],
  imports: [
    IonicPageModule.forChild(RecarehistoryPage),
  ],
})
export class RecarehistoryPageModule {}
