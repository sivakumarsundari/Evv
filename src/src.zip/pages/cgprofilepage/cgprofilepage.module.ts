import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgprofilepagePage } from './cgprofilepage';

@NgModule({
  declarations: [
    CgprofilepagePage,
  ],
  imports: [
    IonicPageModule.forChild(CgprofilepagePage),
  ],
})
export class CgprofilepagePageModule {}
