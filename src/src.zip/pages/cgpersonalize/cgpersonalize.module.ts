import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgpersonalizePage } from './cgpersonalize';

@NgModule({
  declarations: [
    CgpersonalizePage,
  ],
  imports: [
    IonicPageModule.forChild(CgpersonalizePage),
  ],
})
export class CgpersonalizePageModule {}
