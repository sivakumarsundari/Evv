import { Component } from '@angular/core';
import { Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { CgloginPage } from '../pages/cglogin/cglogin';
import { RedashboardPage } from '../pages/redashboard/redashboard';
import { Storage } from '@ionic/storage';
import { CgtabpagesPage } from '../pages/cgtabpages/cgtabpages';
import { GlobalPage } from '../pages/global/global';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
 
  
  rootPage:any;

  constructor(platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen,public storage1 :Storage,
  public global:GlobalPage) {
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      statusBar.styleDefault();
      splashScreen.hide();
      // if(global.employeeId != null || global.clientId != null)
      // {
      //   console.log(global.employeeId);
      //   console.log("global pages");
      //   if(global.isEmployee)
      //   {
      //     this.rootPage=CgtabpagesPage;
      //   }
      //   else if (global.isClient)
      //   {
      //     this.rootPage=RedashboardPage;
      //   }
      //   else
      //   {
      //     this.rootPage = CgloginPage;
      //   }
      // }
      // else
      // {
        console.log("storage page");
      storage1.get("loginAuth").then((val)=>{
        if(val==null){
          this.rootPage = CgloginPage;
          //this.rootPage=RedashboardPage;
        }
        else{
          this.global.Adddata(val);
          if(val.userdetail.isEmployee){
            this.rootPage=CgtabpagesPage;
           // this.rootPage=RedashboardPage;
          }
          else{
            this.rootPage=RedashboardPage;
          }
          
        }
        console.log(val);
        console.log("Stored Data..........................");
      });
   // }
    });
  }

  
}

