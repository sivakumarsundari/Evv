import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgtimesheetprofilePage } from './cgtimesheetprofile';

@NgModule({
  declarations: [
    CgtimesheetprofilePage,
  ],
  imports: [
    IonicPageModule.forChild(CgtimesheetprofilePage),
  ],
})
export class CgtimesheetprofilePageModule {}
