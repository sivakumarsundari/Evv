import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Reapprovetimesheet1Page } from './reapprovetimesheet1';

@NgModule({
  declarations: [
    Reapprovetimesheet1Page,
  ],
  imports: [
    IonicPageModule.forChild(Reapprovetimesheet1Page),
  ],
})
export class Reapprovetimesheet1PageModule {}
