import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgmissingtimesheetmonthPage } from './cgmissingtimesheetmonth';

@NgModule({
  declarations: [
    CgmissingtimesheetmonthPage,
  ],
  imports: [
    IonicPageModule.forChild(CgmissingtimesheetmonthPage),
  ],
})
export class CgmissingtimesheetmonthPageModule {}
