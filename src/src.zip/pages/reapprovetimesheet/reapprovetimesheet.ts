import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { ResignatureverificationPage } from '../resignatureverification/resignatureverification';
import { HttpClient } from '@angular/common/http';
import { GlobalPage } from '../global/global';

/**
 * Generated class for the ReapprovetimesheetPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-reapprovetimesheet',
  templateUrl: 'reapprovetimesheet.html',
})
export class ReapprovetimesheetPage {
  times:time[];  
  item1:items1[];
  mark:cmark[];
  contents:content[];
  services:service[];
  agencyId:number;
  timecardId:number;
  scheduleId:number;
  missedtc:any=[];
  constructor(public navCtrl: NavController, public navParams: NavParams,
    public http: HttpClient, public loadingCtrl: LoadingController,
  public global:GlobalPage) {
      this.times=[{
        image:"assets/imgs/profile5.jpg",
        worktype:"Recipient of Care",
        name:"Tom Moscow",
      },
      {
        image:"assets/imgs/jessica.jpg",
        worktype:"Provided By",
        name:"Jessica Careson",
      },
    ];
    this.item1=[{
      image:"assets/imgs/h.png",
      orgname:"HomeCare First",
      connum:"5555-5555-5555",
      
  }];
    this.mark=[{
      type:"Bathing",
    },
    {
      type:"Grooming",
    },
    {
      type:"Eating",
    },];
    this.contents=[{
      time:"Time In",
      duration:"9:00 AM",
      add:"5151, 1st Avenue Rochester, MN 55555",
      loc:"LOCATION VERIFIED BY GPS",
    },
    {
      time:"Time Out",
      duration:"11:05 AM",
      add:"5151, 1st Avenue Rochester, MN 55555",
      loc:"LOCATION VERIFIED BY GPS",
    },];
    this.services=[{
      servtype:"DATE OF SERVICE",
      quantity:"April 13,2018",
      servtime:"TOTAL TIME",
      duration:"2H 5M",
    },
    {
      servtype:"SERVICE TYPE",
      quantity:"PCA",
      servtime:"RATIO",
      duration:"1:1",
    },];
    }  
    
    ionViewWillEnter() {
    console.log('ionViewDidLoad Reapprovetimesheet1Page');
  }
  submit(subval){
    this.navCtrl.push(ResignatureverificationPage,{"timesheetdetail":subval});
  }
  ionViewDidLoad() {
    console.log("will entre")
    let loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    loading.present();
    
    this.timecardId = this.navParams.get("TimecardId");
    this.agencyId = this.navParams.get("agencyId");
    this.scheduleId = this.navParams.get("ScheduleId");
    console.log(this.agencyId )
    console.log(this.timecardId )
    console.log(this.scheduleId )
    let url = "api/ReTimesheet/submitMTC?";
    let myParams = new URLSearchParams();
    myParams.append("timecardId", this.timecardId.toString());
    myParams.append("ScheduleId", this.scheduleId.toString());
    myParams.append("agencyId", this.agencyId.toString());
    this.http.get(url + myParams).subscribe(
      (data: any) => {
        console.log(data);
        this.missedtc = data;
        loading.dismiss();
   
      },
    err => {
      console.log(err);
      loading.dismiss();
    });

  }
  cancel(){
    this.navCtrl.pop();
  }
}
export class time{
  image:any;
  worktype:String;
  name:String;

}
export class items1{
  orgname:String;
  connum:any;
  image:any;
}
export class cmark{
  type:String;
}
export class content{
  time:String;
  duration:any;
  add:String;
  loc:String;
}
export class service{
  servtype:String;
  quantity:any;
  servtime:String;
  duration:any;
}
 

