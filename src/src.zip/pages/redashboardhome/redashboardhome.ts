import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ReviewappointmentPage } from '../reviewappointment/reviewappointment';
import { RecarehistoryPage } from '../recarehistory/recarehistory';
import { ReprofilePage } from '../reprofile/reprofile';

/**
 * Generated class for the RedashboardhomePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-redashboardhome',
  templateUrl: 'redashboardhome.html',
})
export class RedashboardhomePage {
  records1:record1[];
  records2:record2[];
  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.records1 = [
      {
      rname:"Tom"
      }
    ];
    this.records2 = [
      {
        day:"Today",
        cname:"Jessica Careson",
        starttime:"9:00 AM",
        stoptime:"11:00 AM",
        image:"assets/imgs/jessica.jpg"
      },
      {
        day:"4/23",
        cname:"Jessica Careson",
        starttime:"9:00 AM",
        stoptime:"11:00 AM",
        image:"assets/imgs/jessica.jpg"
      },
      {
        day:"4/27",
        cname:"Jessica Careson",
        starttime:"9:00 AM",
        stoptime:"11:00 AM",
        image:"assets/imgs/jessica.jpg"
      },
      {
        day:"4/30",
        cname:"Jessica Careson",
        starttime:"9:00 AM",
        stoptime:"11:00 AM",
        image:"assets/imgs/jessica.jpg"
      },
      {
        day:"5/4",
        cname:"Jessica Careson",
        starttime:"9:00 AM",
        stoptime:"11:00 AM",
        image:"assets/imgs/jessica.jpg"
      }
    ];
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad RedashboardhomePage');
  }
  viewappt(){
      
    this.navCtrl.push(ReviewappointmentPage);
}
carehistory(){
      
  this.navCtrl.push(RecarehistoryPage);
}
profile(){
      
  this.navCtrl.push(ReprofilePage);
}
}
export class record1 {
  rname:string;
}
export class record2 {
  day:string;
  cname:string;
  starttime:string;
  stoptime:string;
  image:any;
}