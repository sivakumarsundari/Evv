import { IonicStorageModule } from '@ionic/storage';
import { CgtabpagesPage } from '../pages/cgtabpages/cgtabpages';
import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { MyApp } from './app.component';
import { CgloginPage } from '../pages/cglogin/cglogin';
import {CgpersonalizePage} from '../pages/cgpersonalize/cgpersonalize';
import { FullCalendarModule } from 'ng-fullcalendar';
import {CgprofilepagePage} from '../pages/cgprofilepage/cgprofilepage';
import {CgtimesheetcalendarPage} from '../pages/cgtimesheetcalendar/cgtimesheetcalendar';
import {CgmissingtimesheetPage} from '../pages/cgmissingtimesheet/cgmissingtimesheet';
import {CgreviewPage} from '../pages/cgreview/cgreview';
import {CgmissingtimesheetmonthPage} from '../pages/cgmissingtimesheetmonth/cgmissingtimesheetmonth';
import {CgcompletetimesheetPage} from '../pages/cgcompletetimesheet/cgcompletetimesheet';
import { CgpersonalizephotouploadPage } from '../pages/cgpersonalizephotoupload/cgpersonalizephotoupload';
import { CgpersonalizephotoeditPage } from '../pages/cgpersonalizephotoedit/cgpersonalizephotoedit';
import { CgpersonalizedetailsPage } from '../pages/cgpersonalizedetails/cgpersonalizedetails';
import { CgpersonalizeexperiencePage } from '../pages/cgpersonalizeexperience/cgpersonalizeexperience';
import { CgpersonalizecertificatePage } from '../pages/cgpersonalizecertificate/cgpersonalizecertificate';
import { CgviewappointmentPage } from '../pages/cgviewappointment/cgviewappointment';
import { CgblockcalendarPage } from '../pages/cgblockcalendar/cgblockcalendar';
import { CgblockcalendarrepeatPage } from '../pages/cgblockcalendarrepeat/cgblockcalendarrepeat';
import { RedashboardPage } from '../pages/redashboard/redashboard';
import { ReviewappointmentPage } from '../pages/reviewappointment/reviewappointment';
import { RecarehistoryPage } from '../pages/recarehistory/recarehistory';
import { RecarehistorymonthPage } from '../pages/recarehistorymonth/recarehistorymonth';
import { RecarehistorymonthdetailsPage } from '../pages/recarehistorymonthdetails/recarehistorymonthdetails';
import { SignatureverificationPage } from '../pages/signatureverification/signatureverification';
import { SignaturePadModule } from 'angular2-signaturepad';
import { ReapprovetimesheetPage } from '../pages/reapprovetimesheet/reapprovetimesheet';
import { ResignatureverificationPage } from '../pages/resignatureverification/resignatureverification';
import { ReprofilePage } from '../pages/reprofile/reprofile';
import {CgdashboardPage} from '../pages/cgdashboard/cgdashboard';
import {CgtimesheetcarerecipientsPage} from '../pages/cgtimesheetcarerecipients/cgtimesheetcarerecipients';
import {CgtimesheetprofilePage} from '../pages/cgtimesheetprofile/cgtimesheetprofile';
import { AuthProvider } from '../providers/auth/auth';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { GlobalPage } from '../pages/global/global';
import { PopoverPage } from '../pages/popover/popover';
import { Geolocation } from '@ionic-native/geolocation';
import {CgprofilePage} from '../pages/cgprofilepage/cgprofilepage';

@NgModule({
  declarations: [
    MyApp,
    CgloginPage,
    CgpersonalizePage,
    CgtabpagesPage,
    CgprofilepagePage,
    CgtimesheetcalendarPage,
    CgmissingtimesheetPage,
    CgreviewPage,
    CgmissingtimesheetmonthPage,
    CgcompletetimesheetPage,
    SignatureverificationPage,
    CgpersonalizephotouploadPage,
    CgpersonalizephotoeditPage,
    CgpersonalizedetailsPage,
    CgpersonalizeexperiencePage,
    CgpersonalizecertificatePage,
    CgviewappointmentPage,
    CgblockcalendarPage,
    CgblockcalendarrepeatPage,
    RedashboardPage,
    ReviewappointmentPage,
    RecarehistoryPage,
    RecarehistorymonthPage,
    RecarehistorymonthdetailsPage,
    ReapprovetimesheetPage,
    ResignatureverificationPage,
    ReprofilePage,
    CgdashboardPage,
    CgtimesheetcarerecipientsPage,
    CgtimesheetprofilePage,
    GlobalPage,
    PopoverPage,
    CgprofilePage
  ],
  imports: [
    FullCalendarModule,
    BrowserModule,
    HttpClientModule,
    HttpModule,
    SignaturePadModule,
    IonicModule.forRoot(MyApp),
    IonicStorageModule.forRoot()

  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    CgloginPage,
    CgpersonalizePage,
    CgtabpagesPage,
    CgprofilepagePage,
    CgtimesheetcalendarPage,
    CgmissingtimesheetPage,
    CgreviewPage,
    CgmissingtimesheetmonthPage,
    CgcompletetimesheetPage,
    SignatureverificationPage,
    CgpersonalizephotouploadPage,
    CgpersonalizephotoeditPage,
    CgpersonalizedetailsPage,
    CgpersonalizeexperiencePage,
    CgpersonalizecertificatePage,
    CgviewappointmentPage,
    CgblockcalendarPage,
    CgblockcalendarrepeatPage,
    RedashboardPage,
    ReviewappointmentPage,
    RecarehistoryPage,
    RecarehistorymonthPage,
    RecarehistorymonthdetailsPage,
    ReapprovetimesheetPage,
    ResignatureverificationPage,
    ReprofilePage,
    CgdashboardPage,
    CgtimesheetcarerecipientsPage,
    CgtimesheetprofilePage,
    GlobalPage,
    PopoverPage,
    CgprofilePage
    
  ],
  providers: [
    StatusBar,
    SplashScreen,
    GlobalPage,
    Geolocation,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthProvider,
      multi: true
    },
    // AuthProvider
  ]
})
export class AppModule {}
