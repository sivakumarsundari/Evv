import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RecarehistorymonthdetailsPage } from './recarehistorymonthdetails';

@NgModule({
  declarations: [
    RecarehistorymonthdetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(RecarehistorymonthdetailsPage),
  ],
})
export class RecarehistorymonthdetailsPageModule {}
