import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgreviewPage } from './cgreview';

@NgModule({
  declarations: [
    CgreviewPage,
  ],
  imports: [
    IonicPageModule.forChild(CgreviewPage),
  ],
})
export class CgreviewPageModule {}
