import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Cgreview1Page } from '../cgreview1/cgreview1';

/**
 * Generated class for the Cgcompletetimesheet1Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-cgcompletetimesheet1',
  templateUrl: 'cgcompletetimesheet1.html',
})
export class Cgcompletetimesheet1Page {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Cgcompletetimesheet1Page');
  }
  review(){
    this.navCtrl.push(Cgreview1Page);
  }
  cancel(){
    this.navCtrl.pop()
  }
}
