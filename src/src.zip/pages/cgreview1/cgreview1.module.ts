import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Cgreview1Page } from './cgreview1';

@NgModule({
  declarations: [
    Cgreview1Page,
  ],
  imports: [
    IonicPageModule.forChild(Cgreview1Page),
  ],
})
export class Cgreview1PageModule {}
