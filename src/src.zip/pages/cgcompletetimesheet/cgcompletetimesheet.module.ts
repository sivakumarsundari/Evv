import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgcompletetimesheetPage } from './cgcompletetimesheet';

@NgModule({
  declarations: [
    CgcompletetimesheetPage,
  ],
  imports: [
    IonicPageModule.forChild(CgcompletetimesheetPage),
  ],
})
export class CgcompletetimesheetPageModule {}
