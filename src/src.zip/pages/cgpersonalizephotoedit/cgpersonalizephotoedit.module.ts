import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgpersonalizephotoeditPage } from './cgpersonalizephotoedit';

@NgModule({
  declarations: [
    CgpersonalizephotoeditPage,
  ],
  imports: [
    IonicPageModule.forChild(CgpersonalizephotoeditPage),
  ],
})
export class CgpersonalizephotoeditPageModule {}
