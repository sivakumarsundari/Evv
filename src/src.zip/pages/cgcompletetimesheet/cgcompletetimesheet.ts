import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import {CgreviewPage} from '../cgreview/cgreview'
import { CgmissingtimesheetmonthPage } from '../cgmissingtimesheetmonth/cgmissingtimesheetmonth';
import { HttpClient } from '@angular/common/http';
import {CgmissingtimesheetPage} from '../cgmissingtimesheet/cgmissingtimesheet';
declare var $: any;
/**
 * Generated class for the CgcompletetimesheetPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-cgcompletetimesheet',
  templateUrl: 'cgcompletetimesheet.html',
})
export class CgcompletetimesheetPage {
  scheduleIdct:number;
  timecardIdct:number;
  clientName:string;
  tcdetails:any;
  constructor(public navCtrl: NavController, public navParams: NavParams,
    public http: HttpClient, public loadingCtrl: LoadingController,) {
  }
  currentdate=Date.now();
  ionViewDidLoad() {
    console.log('ionViewDidLoad CgcompletetimesheetPage');
  }
  ionViewWillEnter() {
    let loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    loading.present();
    this.scheduleIdct = this.navParams.get("scheduleId");
    this.timecardIdct = this.navParams.get("timecardId");
    console.log(this.scheduleIdct);
    console.log(this.timecardIdct);
    let url = "api/Cgtimesheets/cgCompleteTC?";
    let myParams = new URLSearchParams();
    myParams.append("scheduleId",  this.scheduleIdct.toString());
    myParams.append("timecardId",  this.timecardIdct.toString());
    this.http.get(url + myParams).subscribe(
      (data: any) => {
        console.log(data);
       this.tcdetails = data;
        console.log("navepush");
        loading.dismiss();
      },
    err => {
      console.log(err);
      
    loading.dismiss();
  
    });
}

  
// nction () {
//     $('#myCheckbox').click(function () {
//       $('#myButton').prop("disabled", !$("#myCheckbox").prop("checked")); 
//     })
//     alert();
//   }

  review(rewvalue){
   this.navCtrl.push(CgreviewPage,{"revicedvalue":rewvalue});
    }
  
  cancel(){
    this.navCtrl.pop()
  }

 buttonState() {
    return !this.tcdetails.jobTaskdet.some( jobdet=>jobdet.isCompleted);
  }

//   tester:boolean=true;
//  buttonState() {
//     alert();
//     this.tester= !this.tcdetails.jobTaskdet.some( jobdet=>jobdet.isCompleted);
   
//   }
}
