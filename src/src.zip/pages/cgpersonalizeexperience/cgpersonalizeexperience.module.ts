import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgpersonalizeexperiencePage } from './cgpersonalizeexperience';

@NgModule({
  declarations: [
    CgpersonalizeexperiencePage,
  ],
  imports: [
    IonicPageModule.forChild(CgpersonalizeexperiencePage),
  ],
})
export class CgpersonalizeexperiencePageModule {}
