import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgpersonalizedetailsPage } from './cgpersonalizedetails';

@NgModule({
  declarations: [
    CgpersonalizedetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(CgpersonalizedetailsPage),
  ],
})
export class CgpersonalizedetailsPageModule {}
