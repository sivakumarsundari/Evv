import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ReapprovetimesheetPage } from './reapprovetimesheet';

@NgModule({
  declarations: [
    ReapprovetimesheetPage,
  ],
  imports: [
    IonicPageModule.forChild(ReapprovetimesheetPage),
  ],
})
export class ReapprovetimesheetPageModule {}
