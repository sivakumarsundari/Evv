import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Resignatureverification1Page } from './resignatureverification1';

@NgModule({
  declarations: [
    Resignatureverification1Page,
  ],
  imports: [
    IonicPageModule.forChild(Resignatureverification1Page),
  ],
})
export class Resignatureverification1PageModule {}
