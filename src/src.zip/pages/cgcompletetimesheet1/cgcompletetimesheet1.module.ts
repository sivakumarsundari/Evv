import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Cgcompletetimesheet1Page } from './cgcompletetimesheet1';

@NgModule({
  declarations: [
    Cgcompletetimesheet1Page,
  ],
  imports: [
    IonicPageModule.forChild(Cgcompletetimesheet1Page),
  ],
})
export class Cgcompletetimesheet1PageModule {}
