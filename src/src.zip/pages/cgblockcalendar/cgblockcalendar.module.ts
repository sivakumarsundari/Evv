import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgblockcalendarPage } from './cgblockcalendar';

@NgModule({
  declarations: [
    CgblockcalendarPage,
  ],
  imports: [
    IonicPageModule.forChild(CgblockcalendarPage),
  ],
})
export class CgblockcalendarPageModule {}
