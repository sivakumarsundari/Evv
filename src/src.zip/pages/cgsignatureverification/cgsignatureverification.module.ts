import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgsignatureverificationPage } from './cgsignatureverification';

@NgModule({
  declarations: [
    CgsignatureverificationPage,
  ],
  imports: [
    IonicPageModule.forChild(CgsignatureverificationPage),
  ],
})
export class CgsignatureverificationPageModule {}
