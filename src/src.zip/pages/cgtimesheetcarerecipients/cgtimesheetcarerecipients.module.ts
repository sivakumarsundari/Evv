import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgtimesheetcarerecipientsPage } from './cgtimesheetcarerecipients';

@NgModule({
  declarations: [
    CgtimesheetcarerecipientsPage,
  ],
  imports: [
    IonicPageModule.forChild(CgtimesheetcarerecipientsPage),
  ],
})
export class CgtimesheetcarerecipientsPageModule {}
