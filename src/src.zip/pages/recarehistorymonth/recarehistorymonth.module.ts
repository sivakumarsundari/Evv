import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RecarehistorymonthPage } from './recarehistorymonth';

@NgModule({
  declarations: [
    RecarehistorymonthPage,
  ],
  imports: [
    IonicPageModule.forChild(RecarehistorymonthPage),
  ],
})
export class RecarehistorymonthPageModule {}
