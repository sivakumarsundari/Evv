import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgloginPage } from './cglogin';

@NgModule({
  declarations: [
    CgloginPage,
  ],
  imports: [
    IonicPageModule.forChild(CgloginPage),
  ],
})
export class CgloginPageModule {}
