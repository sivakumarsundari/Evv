import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgmissingtimesheetPage } from './cgmissingtimesheet';

@NgModule({
  declarations: [
    CgmissingtimesheetPage,
  ],
  imports: [
    IonicPageModule.forChild(CgmissingtimesheetPage),
  ],
})
export class CgmissingtimesheetPageModule {}
