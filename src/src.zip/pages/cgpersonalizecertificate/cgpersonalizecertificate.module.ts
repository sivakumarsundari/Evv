import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgpersonalizecertificatePage } from './cgpersonalizecertificate';

@NgModule({
  declarations: [
    CgpersonalizecertificatePage,
  ],
  imports: [
    IonicPageModule.forChild(CgpersonalizecertificatePage),
  ],
})
export class CgpersonalizecertificatePageModule {}
