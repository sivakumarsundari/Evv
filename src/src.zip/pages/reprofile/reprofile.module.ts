import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ReprofilePage } from './reprofile';

@NgModule({
  declarations: [
    ReprofilePage,
  ],
  imports: [
    IonicPageModule.forChild(ReprofilePage),
  ],
})
export class ReprofilePageModule {}
