import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgviewappointmentPage } from './cgviewappointment';

@NgModule({
  declarations: [
    CgviewappointmentPage,
  ],
  imports: [
    IonicPageModule.forChild(CgviewappointmentPage),
  ],
})
export class CgviewappointmentPageModule {}
