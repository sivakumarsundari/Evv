import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgcarehistoryPage } from './cgcarehistory';

@NgModule({
  declarations: [
    CgcarehistoryPage,
  ],
  imports: [
    IonicPageModule.forChild(CgcarehistoryPage),
  ],
})
export class CgcarehistoryPageModule {}
