import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgtabpagesPage } from './cgtabpages';

@NgModule({
  declarations: [
    CgtabpagesPage,
  ],
  imports: [
    IonicPageModule.forChild(CgtabpagesPage),
  ]
})
export class CgtabpagesPageModule {}
