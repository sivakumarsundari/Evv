import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CgpersonalizephotouploadPage } from './cgpersonalizephotoupload';

@NgModule({
  declarations: [
    CgpersonalizephotouploadPage,
  ],
  imports: [
    IonicPageModule.forChild(CgpersonalizephotouploadPage),
  ],
})
export class CgpersonalizephotouploadPageModule {}
