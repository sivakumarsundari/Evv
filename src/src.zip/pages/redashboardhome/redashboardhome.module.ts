import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RedashboardhomePage } from './redashboardhome';

@NgModule({
  declarations: [
    RedashboardhomePage,
  ],
  imports: [
    IonicPageModule.forChild(RedashboardhomePage),
  ],
})
export class RedashboardhomePageModule {}
